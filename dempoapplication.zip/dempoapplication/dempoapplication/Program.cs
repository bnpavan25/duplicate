using System;
using System.Threading.Tasks;
using System.Configuration;
using System.Collections.Generic;
using System.Net;
using Microsoft.Azure.Cosmos;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections;
//using Microsoft.Azure.Documents.Client;
//using Microsoft.Azure.Documents;


namespace CosmosGettingStartedTutorial
{
    class Program
    {
       
        // <Main>
        public static async Task Main(string[] args)
        {
            try
            {
                Console.WriteLine("Beginning operations...\n");
                Program p = new Program();
                await p.GetStartedDemoAsync();

            }
            catch (CosmosException cosmosException)
            {
                Console.WriteLine("Cosmos Exception with Status {0} : {1}\n", cosmosException.StatusCode, cosmosException);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e);
            }
            finally
            {
                Console.WriteLine("End of demo, press any key to exit.");
                Console.ReadKey();
            }
        }
        // </Main>

        // <GetStartedDemoAsync>
        /// <summary>
        /// Entry point to call methods that operate on Azure Cosmos DB resources in this sample
        /// </summary>
        public async Task GetStartedDemoAsync()
        {
           
            await this.FindDuplicates();
        }

        private async Task FindDuplicates()
        {

            string connStr = "AccountEndpoint=https://dbaccountName.documents.azure.com:443/;AccountKey=enterprimarykey;";

            CosmosClient client = new CosmosClient(connStr, new CosmosClientOptions() { ConnectionMode = ConnectionMode.Direct });

            Database database = client.GetDatabase("test");
            Container container = database.GetContainer("t3");//("testcol2");



            


            ////search for a item
            //QueryDefinition queryDefinition = new QueryDefinition("SELECT * FROM testcol2 t WHERE t._rid=@rid").WithParameter("@rid", "mHpZAIjnIr4DAAAAAAAAAA==");
            //using (FeedIterator<JObject> results = container.GetItemQueryIterator<JObject>(queryDefinition))
            //{
            //    while (results.HasMoreResults)
            //    {
            //        FeedResponse<JObject> response = await results.ReadNextAsync();
            //        foreach (JObject document in response)
            //        {
            //            Console.WriteLine(JsonConvert.SerializeObject(document));
            //        }
            //        Console.WriteLine("==========================================/n");
            //    }
            //}
            //Console.WriteLine("==========================================/n");

            ////Code to fetch corrupted documents
            //QueryDefinition queryDefinition2 = new QueryDefinition("SELECT t._rid,t.id FROM testcol2 t where t.id not like @text ").WithParameter("@text","NjN%");
            //using (FeedIterator<JObject> results = container.GetItemQueryIterator<JObject>(queryDefinition2))
            //{
            //    while (results.HasMoreResults)
            //    {
            //        FeedResponse<JObject> response = await results.ReadNextAsync();
            //        foreach (JObject document in response)
            //        {
            //            Console.WriteLine(JsonConvert.SerializeObject(document));
            //            Console.WriteLine("==========================================/n");
            //        }
            //    }
            //}
            //Console.WriteLine("==========================================/n");

            ////// Create an item
            //dynamic testItem = new { id = "1", partitionKeyPath = "pk", details = "it's working", status = "done" };
            //_ = await container.CreateItemAsync(testItem);

            //// Query for an item
            //using (FeedIterator<dynamic> feedIterator = container.GetItemQueryIterator<dynamic>(
            //    "select * from T where T.status = 'done'"))
            //{
            //    while (feedIterator.HasMoreResults)
            //    {
            //        FeedResponse<dynamic> response = await feedIterator.ReadNextAsync();
            //        foreach (var item in response)
            //        {
            //            Console.WriteLine(item);
            //        }
            //    }
            //}
        }


    }
}
